// // import firstPage from "../Controller/recipeController";
// const {
//   firstPage,
//   addRecipe,
//   newRecipe,
//   editRecipe,
//   deleteRecipe,
//   detailRecipe,
//   finallyEdit,
// } = require("../Controller/recipeController");

// const express = require("express");
// const router = express.Router();

// router.get("/home", firstPage); //all recipe
// router.get("/new", newRecipe);
// router.post("/new", addRecipe);
// router.get("/:id/edit", editRecipe); //Edit recipe
// router.put("/:id", finallyEdit);
// router.get("/:id", detailRecipe); //get single recipe
// router.delete("/:id/delete", deleteRecipe); //delete recipe

// module.exports = router;
const {
  firstPage,
  addRecipe,
  newRecipe,
  editRecipe,
  deleteRecipe,
  detailRecipe,
  finallyEdit,
} = require("../Controller/recipeController");

const express = require("express");
const router = express.Router();

router.get("/home", firstPage); // all recipes
router.get("/new", newRecipe); // form to add recipe
router.post("/new", addRecipe); // save new recipe
router.get("/:id/edit", editRecipe); // edit form
router.put("/:id", finallyEdit); // update
router.get("/:id", detailRecipe); // show details
router.delete("/:id/delete", deleteRecipe); // delete

module.exports = router;
