const express = require("express");
const connectDb = require("./Config/connectionDb");
const dotenv = require("dotenv").config();
const app = express();
const path = require("path");
const methodoverride = require("method-override");
const ejsmate = require("ejs-mate");
const wrapAsync = require("./Utils/wrapAsync");
const Recipe = require("./Models/recipeStructure.js");

const PORT = process.env.PORT || 4000;
connectDb();

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "Views"));
app.use(express.urlencoded({ extended: true }));
app.use(methodoverride("_method"));
app.engine("ejs", ejsmate);
app.use(express.static(path.join(__dirname, "/public")));

app.get("/food/home", async (req, res) => {
  const allRecipe = await Recipe.find({});
  res.render("home.ejs", { allRecipe });
});

app.get("/food/new", async (req, res) => {
  res.render("newRecipe.ejs");
}); // form to add recipe

app.post(
  "/food/new",
  wrapAsync(async (req, res, next) => {
    let recipe = req.body.recipe;
    let newRecipe = new Recipe(recipe);
    await newRecipe.save();
    res.redirect("/food/home");
  })
); // save new recipe

app.get(
  "/food/:id/edit",
  wrapAsync(async (req, res) => {
    let { id } = req.params;
    const foodDetail = await Recipe.findById(id);
    res.render("edit.ejs", { foodDetail });
  })
); // edit form

app.put("/food/:id", async (req, res) => {
  let { id } = req.params;
  await Recipe.findByIdAndUpdate(id, { ...req.body.recipe });
  // console.log("finallyedi", { ...req.body.recipe });
  res.redirect("/food/home");
}); // update

app.get("/food/:id", async (req, res) => {
  let { id } = req.params;
  const foodDetail = await Recipe.findById(id);
  res.render("show.ejs", { foodDetail });
}); // show details

app.delete("/food/:id/delete", async (req, res) => {
  let { id } = req.params;
  await Recipe.findByIdAndDelete(id);
  res.redirect("/food/home");
}); // delete

app.use("*", (req, res, next) => {
  console.log("all");
  const err = new Error("page not found");
  err.statusCode = 404;
  next(err);
});

app.use((err, req, res, next) => {
  let { statusCode = 500, message = "Internal server error" } = err;
  console.log(statusCode);
  res.status(statusCode).send(message);
});

app.listen(PORT, (err) => {
  console.log("App is listening at port " + PORT);
});
