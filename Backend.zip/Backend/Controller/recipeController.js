const Recipe = require("../Models/recipeStructure");
const wrapAsync = require("../Utils/wrapAsync");

const firstPage = async (req, res) => {
  const allRecipe = await Recipe.find({});
  res.render("home.ejs", { allRecipe });
};

const newRecipe = async (req, res) => {
  res.render("newRecipe.ejs");
};

const addRecipe = wrapAsync(async (req, res, next) => {
  let recipe = req.body.recipe;
  let newRecipe = new Recipe(recipe);
  await newRecipe.save();
  res.redirect("/food/home");
});

const finallyEdit = async (req, res) => {
  let { id } = req.params;
  await Recipe.findByIdAndUpdate(id, { ...req.body.recipe });
  // console.log("finallyedi", { ...req.body.recipe });
  res.redirect("/food/home");
};

const editRecipe = async (req, res) => {
  let { id } = req.params;
  const foodDetail = await Recipe.findById(id);
  res.render("edit.ejs", { foodDetail });
};

const detailRecipe = async (req, res) => {
  let { id } = req.params;
  const foodDetail = await Recipe.findById(id);
  res.render("show.ejs", { foodDetail });
};

const deleteRecipe = async (req, res) => {
  let { id } = req.params;
  await Recipe.findByIdAndDelete(id);
  res.redirect("/food/home");
};

module.exports = {
  firstPage,
  addRecipe,
  editRecipe,
  detailRecipe,
  deleteRecipe,
  newRecipe,
  finallyEdit,
};
